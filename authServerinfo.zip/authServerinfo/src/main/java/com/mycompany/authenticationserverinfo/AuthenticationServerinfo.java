package com.mycompany.authenticationserverinfo;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;

public class AuthenticationServerinfo {
    private static final String[] logins = {"tamucc", "pass@123", "admin", "admin@1", "girish", "gk@12", "gopi", "gopi@1"};

    public static void main(String[] args) {
        try (ServerSocket serverSocket = new ServerSocket(12345)) {
            System.out.println("Server waiting for client connections...");

            while (true) {
                Socket socket = serverSocket.accept();
                handleClient(socket);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void handleClient(Socket socket) {
        try (DataInputStream dis = new DataInputStream(socket.getInputStream());
             DataOutputStream dos = new DataOutputStream(socket.getOutputStream())) {

            String username = dis.readUTF();
            String password = dis.readUTF();

            boolean isValid = checkCredentials(username, password);

            dos.writeUTF(isValid ? "yes" : "no");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static boolean checkCredentials(String username, String password) {
        for (int i = 0; i < logins.length; i += 2) {
            if (username.equals(logins[i]) && password.equals(logins[i + 1])) {
                return true;
            }
        }
        return false;
    }
}
