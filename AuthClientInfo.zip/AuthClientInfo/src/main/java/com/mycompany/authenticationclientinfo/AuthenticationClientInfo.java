package com.mycompany.authenticationclientinfo;

import java.io.*;
import java.net.Socket;
import javax.swing.JOptionPane;

public class AuthenticationClientInfo {

    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(() -> new loginpage().setVisible(true));
    }

    public static void authenticate(String username, String password) {
        try (Socket socket = new Socket("localhost", 12345);
             DataInputStream dis = new DataInputStream(socket.getInputStream());
             DataOutputStream dos = new DataOutputStream(socket.getOutputStream())) {

            dos.writeUTF(username);
            dos.writeUTF(password);

            String response = dis.readUTF();
            showMessageDialog(response);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void showMessageDialog(String response) {
        JOptionPane.showMessageDialog(null, response.equals("yes") ? "Authentication successful" : "Authentication failed");
    }
}
