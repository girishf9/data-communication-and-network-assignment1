
package echoclient;
import java.net.*;
import java.io.*;
import javax.swing.*;

public class EchoClient {

    public static void main(String[] args) {
        ServerInfoForm serverInfoForm = new ServerInfoForm();
        serverInfoForm.setVisible(true);
    }
}

