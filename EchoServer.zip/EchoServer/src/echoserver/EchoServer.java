/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package echoserver;
import java.net.*;
import java.io.*;

public class EchoServer {
    public static void main(String[] args) {
        // TODO code application logic here
        EchoServer server=new EchoServer();
        server.startServer();
    }
    public void startServer(){
        try{
        ServerSocket serverSocket=new ServerSocket(8000);
        while(true)
        {
        System.out.println("Waiting for connection....\n");    
        Socket socket=serverSocket.accept();
        System.out.println("Connection received ...");
        OutputStream outStream=socket.getOutputStream();
        InputStream inStream=socket.getInputStream();
        ObjectOutputStream objOutStream=new ObjectOutputStream(outStream);
        ObjectInputStream objInStream=new ObjectInputStream(inStream);
        String message=(String)objInStream.readObject();
        System.out.println("Server received the following message from the client\n"+message);
        System.out.println("I am going to return it as is to her: i.e. echo it\n");
        objOutStream.writeObject(message);
        objOutStream.flush();
        socket.close();
        }
        }
        catch(Exception e){System.out.println(e.getMessage());}
       }
    }
